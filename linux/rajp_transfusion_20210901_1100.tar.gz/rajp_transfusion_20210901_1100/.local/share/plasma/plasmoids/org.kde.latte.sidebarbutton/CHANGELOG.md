### CHANGELOG

#### Version 0.2.0

* provide All Edges option in order to trigger docks and panels independent of their screen edge
* provide Dock, Panel Name option in order to filter which docks panels you want to handle
* use Plasma.IconItem and remove any Latte icons dependency

#### Version 0.1.2

* remove no needed dependency form config window

#### Version 0.1.1

* support latest libraries from Latte git version

#### Version 0.1.0

* option to choose icon that will be used
* option to choose the maximum icon size
* option to choose sidebar based on screen edge, name and latte layout

